# START HERE — AI SEO Skill

Hi! This little tool teaches Claude how to help you show up in AI search results — things like ChatGPT, Google's AI answers, Perplexity, and Gemini.

Once you install it, you can just chat with Claude like:

> "Audit my website for AI search"
> "Why am I not showing up in ChatGPT?"
> "How do I get my blog quoted by AI?"

…and Claude will know exactly what to do.

---

## What you need before you start

You need **Claude Code** installed on your computer. It's free to install (you pay for usage).

- Get it here: https://claude.com/claude-code
- It works on Mac, Windows, and Linux.

If you don't have Claude Code yet, install that first. Then come back to this guide.

---

## How to install — 3 steps, takes 2 minutes

### Step 1 — Find the right folder on your computer

This is where Claude looks for its tools (called "skills").

**If you have a Mac:**
1. Open **Finder**
2. Press these 3 keys together: `Cmd` + `Shift` + `G`
3. A little box pops up. Paste this into it: `~/.claude/skills/`
4. Press **Enter**

**If you have a Windows PC:**
1. Open **File Explorer**
2. Click on the address bar at the top (where it shows the folder path)
3. Paste this in: `%USERPROFILE%\.claude\skills\`
4. Press **Enter**

> If a window pops up saying the folder doesn't exist, that's fine — just create a folder called `skills` inside the `.claude` folder.

### Step 2 — Drop the skill in

You should now be looking at the `skills` folder.

1. Open this zip file (the one you just downloaded).
2. Inside, you'll see a folder called **`ai-seo`**.
3. **Drag that whole `ai-seo` folder** into the `skills` folder you just opened.

That's it. No installing. No setup. No passwords. Done.

### Step 3 — Test that it works

1. Open **Terminal** (Mac) or **Command Prompt / PowerShell** (Windows).
2. Type `claude` and press **Enter**. Claude Code starts up.
3. Type this and press Enter:

> Help me show up in ChatGPT answers

If Claude starts asking you questions about your business, your website, and what you want people to find you for — **it's working.** 🎉

---

## How to use it (the fun part)

Just chat. Claude will pick up the skill automatically when you ask the right kind of question. Things to try:

- "Audit my website for AI search."
- "Why am I not showing up in Google's AI answers?"
- "What should I change on my blog so ChatGPT quotes it?"
- "How do I get cited by Perplexity?"
- "My competitor shows up in AI answers and I don't. Fix it."
- "Check if my robots.txt is blocking AI bots."

If Claude ever seems confused, just say:

> Use the ai-seo skill.

…and it will pull this tool in directly.

---

## What's inside this skill?

A complete playbook on AI search optimization, including:

- How each AI platform (ChatGPT, Perplexity, Gemini, Google AI Overviews, Claude, Copilot) picks the sources it cites.
- The 3 things you need to win: **Structure**, **Authority**, and **Presence**.
- A 9-tactic ranking table from Princeton's research on which tricks actually boost AI visibility (and which ones HURT it — yes, some popular advice is wrong).
- Content templates for "What is X?", "How to X", "X vs Y", FAQs, and more.
- How to check if AI bots can even read your site (a huge missed step).
- Which schema markup to add for different content types.
- A monthly checklist for tracking your AI visibility for free, without paid tools.

---

## Help! Something broke

**"Claude doesn't seem to know about the skill."**
- Make sure the folder is named exactly `ai-seo` (no extra spaces, no capital letters).
- Make sure it's directly inside the `skills` folder, not nested inside another folder.
- Restart Claude Code (close it and run `claude` again).

**"I can't find the `.claude` folder."**
- The `.` at the start makes it hidden by default.
- **Mac:** In Finder, press `Cmd + Shift + .` (period) to show hidden folders.
- **Windows:** In File Explorer, click the **View** tab → tick **Hidden items**.

**"I don't have Claude Code installed."**
- Grab it here: https://claude.com/claude-code
- Then come back to Step 1 above.

---

That's everything. Enjoy! 🚀
